# Health — tracker (Week 11)

**Route:** `/Health`

**Files**
- `app/Health/page.tsx` — Page shell with a demo series
- `app/Health/components/TrendBars.tsx` — Horizontal bars with exponential height scaling (adjustable k=1.0–3.0)

**Notes**
- Tailwind-only. Replace demo data with live metrics when ready.
