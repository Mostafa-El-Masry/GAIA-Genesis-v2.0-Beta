# Wealth — tracker (Week 11)

**Route:** `/Wealth`

**Files**
- `app/Wealth/page.tsx` — Page shell with a demo series
- `app/Wealth/components/WealthBars.tsx` — Bars with exponential height scaling (k=1.8 default)

**Notes**
- Tailwind-only. Replace demo data with your real savings/projections when ready.
