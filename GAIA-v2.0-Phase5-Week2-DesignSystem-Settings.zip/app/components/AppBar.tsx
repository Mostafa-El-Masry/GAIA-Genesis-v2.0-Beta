'use client';

import Link from "next/link";
import SearchInput from "@/app/DesignSystem/components/SearchInput";

export default function AppBar() {
  return (
    <div className="fixed inset-x-0 top-0 z-40 border-b border-gray-200 bg-white/80 backdrop-blur">
      <div className="mx-auto flex h-14 max-w-6xl items-center gap-3 px-4">
        <Link href="/" className="select-none text-lg font-bold">G</Link>
        <div className="flex-1" />
        <div className="flex w-full max-w-xl items-center gap-2">
          <SearchInput />
        </div>
        {/* Placeholder for user menu entry; Settings route exists at /Settings */}
        <Link href="/Settings" className="ml-3 text-sm text-gray-600 hover:text-gray-900">Settings</Link>
      </div>
    </div>
  );
}
