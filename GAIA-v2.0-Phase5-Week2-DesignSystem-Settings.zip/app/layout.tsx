import "./globals.css";
import type { Metadata } from "next";
import { ThemeRoot } from "./DesignSystem";

export const metadata: Metadata = {
  title: "GAIA",
  description: "GAIA v2.0 · Phase 5",
};

export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html lang="en">
      <body>
        {/* Week 2: Design System ThemeRoot (applies data-theme from localStorage) */}
        <ThemeRoot>
          {/* AppBar is expected to be rendered in a shared layout or directly above */}
          <div className="pt-14">{children}</div>
        </ThemeRoot>
      </body>
    </html>
  );
}
