# TRACE_UI-THEME.md (Week 2 update)

Theme and primitives touch points with file paths and line numbers:

- `app/layout.tsx` · L3: import { ThemeRoot } from "./DesignSystem";
- `app/layout.tsx` · L18: {/* Week 2: Design System ThemeRoot (applies data-theme from localStorage) */}
- `app/layout.tsx` · L19: <ThemeRoot>
- `app/layout.tsx` · L22: </ThemeRoot>
- `app/layout.tsx` · L18: {/* Week 2: Design System ThemeRoot (applies data-theme from localStorage) */}
- `app/DesignSystem/ThemeRoot.tsx` · L9: * - Applies it to <html data-theme="..."> for future theming.
- `app/DesignSystem/ThemeRoot.tsx` · L20: document.documentElement.setAttribute("data-theme", initial);
- `app/DesignSystem/ThemeRoot.tsx` · L30: document.documentElement.setAttribute("data-theme", next);
- `app/DesignSystem/ThemeRoot.tsx` · L8: * - Reads per-user theme from localStorage ("gaia.theme").
- `app/DesignSystem/ThemeRoot.tsx` · L16: const stored = (typeof window !== "undefined" && window.localStorage.getItem("gaia.theme")) as Theme | null;
- `app/DesignSystem/ThemeRoot.tsx` · L10: * - Emits "gaia:theme" CustomEvent when theme changes.
- `app/DesignSystem/ThemeRoot.tsx` · L34: window.addEventListener("gaia:theme", onTheme as EventListener);
- `app/DesignSystem/ThemeRoot.tsx` · L35: return () => window.removeEventListener("gaia:theme", onTheme as EventListener);
- `app/components/AppBar.tsx` · L4: import SearchInput from "@/app/DesignSystem/components/SearchInput";
- `app/components/AppBar.tsx` · L13: <SearchInput />
- `app/Settings/components/ThemePicker.tsx` · L3: import { DEFAULT_THEME, THEMES } from "@/app/DesignSystem";
- `app/Settings/components/ThemePicker.tsx` · L11: setTheme(stored && THEMES.includes(stored as any) ? (stored as string) : DEFAULT_THEME);
- `app/Settings/components/ThemePicker.tsx` · L15: if (!THEMES.includes(next as any)) return;
- `app/Settings/components/ThemePicker.tsx` · L30: {THEMES.map((t) => (
- `app/Settings/components/ThemePicker.tsx` · L10: const stored = window.localStorage.getItem("gaia.theme");
- `app/Settings/components/ThemePicker.tsx` · L17: window.localStorage.setItem("gaia.theme", next);
- `app/Settings/components/ThemePicker.tsx` · L18: document.documentElement.setAttribute("data-theme", next);
- `app/Settings/components/ThemePicker.tsx` · L36: <p className="text-xs text-gray-500">Phase 5 baseline: themes apply globally via <code>data-theme</code>.</p>
- `app/Settings/components/ThemePicker.tsx` · L19: window.dispatchEvent(new CustomEvent("gaia:theme", { detail: { theme: next } }));
- `app/DesignSystem/components/SearchInput.tsx` · L7: * - Emits CustomEvent("gaia:search", { detail: { q }}) on Enter
- `app/DesignSystem/components/SearchInput.tsx` · L13: const event = new CustomEvent("gaia:search", { detail: { q } });
