# Download Center — tracker (Week 12)
**Route:** `/Classic/DownloadCenter`
**Files**
- `app/Classic/DownloadCenter/page.tsx`
- `app/Classic/DownloadCenter/components/DownloadCenterClient.tsx`
- `app/Classic/DownloadCenter/data/files.ts`
**Notes**
- Edit `data/files.ts` to add your zips; for local files, place them under `/public/downloads/`.
