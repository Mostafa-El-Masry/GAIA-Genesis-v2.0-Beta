# Manual Site Map — tracker (Week 12)
**Route:** `/Classic/SiteMap`
**Files**
- `app/Classic/SiteMap/page.tsx`
- `app/Classic/SiteMap/components/SiteMapClient.tsx`
- `app/Classic/SiteMap/data/routes.ts`
