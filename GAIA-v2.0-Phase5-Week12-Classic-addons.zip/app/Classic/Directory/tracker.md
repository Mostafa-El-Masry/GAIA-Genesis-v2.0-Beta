# Dev-only Directory — tracker (Week 12)
**Route:** `/Classic/Directory`
**Files**
- `app/Classic/Directory/page.tsx`
- `app/Classic/Directory/components/DirectoryClient.tsx`
- `app/Classic/Directory/data/routes.ts`
**Notes**
- Hidden in production via `process.env.NODE_ENV` check in the client.
