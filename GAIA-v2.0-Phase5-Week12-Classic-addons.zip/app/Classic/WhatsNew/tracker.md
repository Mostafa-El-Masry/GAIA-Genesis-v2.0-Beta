# What’s New — tracker (Week 12)
**Route:** `/Classic/WhatsNew`
**Files**
- `app/Classic/WhatsNew/page.tsx`
- `app/Classic/WhatsNew/components/WhatsNewClient.tsx`
- `app/Classic/WhatsNew/data/entries.ts`
