# Classic Shared — tracker (Week 12)
**Components**
- `app/Classic/Shared/components/LastUpdatedBadge.tsx` — shows document lastModified (or provided date)
- `app/Classic/Shared/components/ViewCounter.tsx` — local-only per-path view counter
