export type Announcement = { id: string; date: string; title: string; body: string };

export const posts: Announcement[] = [
  { id: "a1", date: "2026-04-05", title: "Phase 5 beta is live", body: "We are moving fast but intentionally keeping scope focused. Expect frequent small drops." }
];
