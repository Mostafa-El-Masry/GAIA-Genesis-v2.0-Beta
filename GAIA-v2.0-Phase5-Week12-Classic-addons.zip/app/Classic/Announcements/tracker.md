# Announcements — tracker (Week 12)
**Route:** `/Classic/Announcements`
**Files**
- `app/Classic/Announcements/page.tsx`
- `app/Classic/Announcements/components/AnnouncementsClient.tsx`
- `app/Classic/Announcements/data/posts.ts`
