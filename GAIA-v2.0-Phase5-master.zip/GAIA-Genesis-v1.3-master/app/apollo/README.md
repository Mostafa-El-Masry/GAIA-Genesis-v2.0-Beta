Drop this folder under `app/apollo/`. Ensure `import "./styles/layout.css";` stays at the very top of `page.tsx`.
