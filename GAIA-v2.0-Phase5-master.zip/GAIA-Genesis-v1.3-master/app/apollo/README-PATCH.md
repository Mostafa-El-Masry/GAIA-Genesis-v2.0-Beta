Patch: Apollo now reads the URL hash to open a specific section ID. Links like `/apollo#<sectionId>` will deep-link.
