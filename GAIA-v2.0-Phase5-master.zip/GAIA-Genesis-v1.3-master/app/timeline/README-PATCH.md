Patch: Adds GAIA quick-add buttons and Apollo section linking (`/apollo#<sectionId>`) to the Timeline EventForm.
