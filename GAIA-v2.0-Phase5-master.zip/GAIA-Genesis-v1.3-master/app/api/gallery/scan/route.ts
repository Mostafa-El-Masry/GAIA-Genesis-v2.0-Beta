export { GET } from "../route";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";
