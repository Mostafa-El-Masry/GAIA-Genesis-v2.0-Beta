﻿import ClientPage from "./ClientPage";

export const dynamic = "force-dynamic";
export const revalidate = 0;

export default function SearchPage() {
  return <ClientPage />;
}
