# GAIA v1.3 — Week 6: Wealth (Updated)
- Centralized Sync/Backup -> **/sync**. Removed Wealth page Export/Import.
- Keep: Simulator (Plans A/B, reinvest after 7y, min reinvest 1,000 EGP), WealthLevels.

Files affected:
- app/wealth/page.tsx — removed <ExportImport /> and its import.
