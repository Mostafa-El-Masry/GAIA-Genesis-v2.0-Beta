Remove any direct link to `/sync`. If you list settings, link to `/settings` and the Backup tab via `/settings#backup` when needed.
