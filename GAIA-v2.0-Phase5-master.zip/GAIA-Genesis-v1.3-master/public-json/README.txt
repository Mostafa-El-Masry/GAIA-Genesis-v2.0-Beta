Place your backup file(s) here:

- /public/json/gaia-v1.3-backup.json  (recommended)
- /public/json/backup.json
- /public/json/gaia-backup.json

On load, GAIA will import the first one it finds (plain bundle or encrypted).