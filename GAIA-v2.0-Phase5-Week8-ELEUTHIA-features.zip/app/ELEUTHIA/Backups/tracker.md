# Backups — tracker (Week 8)

**Route:** `/ELEUTHIA/Backups`

**Files**
- `app/ELEUTHIA/Backups/page.tsx` — Page shell
- `app/ELEUTHIA/Backups/components/BackupsClient.tsx` — Export/Import encrypted backups + local snapshots
- `app/ELEUTHIA/lib/snapshots.ts` — Snapshot utilities (encrypted payload only)
