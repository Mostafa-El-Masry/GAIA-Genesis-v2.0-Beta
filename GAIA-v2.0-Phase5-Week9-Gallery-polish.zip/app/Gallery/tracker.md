# Gallery — tracker (Week 9 online polish)

**Route:** `/Gallery`

**Files**
- `app/Gallery/page.tsx` — Page shell (client-only via dynamic import to ensure pointer events work consistently)
- `app/Gallery/components/GalleryClient.tsx` — Carousel with desktop arrows, mobile swipe, edge-fade hints, preloading, and stable aspect ratio
- `app/Gallery/data/images.ts` — Replace with your real images (src + width/height) for no layout shift

**Notes**
- Tailwind-only; no CSS files. Uses `aspect-ratio` style inline to prevent reflow.
- Preloads next/prev images to avoid flash.
- Keyboard ←/→ supported.
