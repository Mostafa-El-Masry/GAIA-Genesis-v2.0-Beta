export type GalleryImage = {
  src: string;
  w: number;
  h: number;
  title?: string;
  caption?: string;
};

// Replace these with your actual paths under /public or remote URLs allowed by Next config.
export const images: GalleryImage[] = [
  { src: "/images/gallery/sample-1.jpg", w: 1600, h: 900, title: "Sample 1" },
  { src: "/images/gallery/sample-2.jpg", w: 1200, h: 1600, title: "Sample 2 (Portrait)" },
  { src: "/images/gallery/sample-3.jpg", w: 2048, h: 1365, title: "Sample 3" },
];
