'use client';

import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import { images } from "../data/images";

type Dir = -1 | 1;

export default function GalleryClient() {
  const [i, setI] = useState(0);
  const [ratio, setRatio] = useState<number>(() => images[0]?.w && images[0]?.h ? images[0].w / images[0].h : 16/9);
  const wrapRef = useRef<HTMLDivElement | null>(null);
  const imgRef = useRef<HTMLImageElement | null>(null);
  const down = useRef<{ x: number; y: number; t: number } | null>(null);

  const img = images[i];
  const next = images[(i + 1) % images.length];
  const prev = images[(i - 1 + images.length) % images.length];

  // Preload neighbors to avoid flash
  useEffect(() => {
    [next, prev].forEach((it) => {
      if (!it) return;
      const im = new Image();
      im.src = it.src;
    });
  }, [i]);

  // Keyboard navigation
  useEffect(() => {
    function onKey(e: KeyboardEvent) {
      if (e.key === "ArrowRight") go(1);
      else if (e.key === "ArrowLeft") go(-1);
    }
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, []);

  const go = useCallback((dir: Dir) => {
    setI((cur) => {
      const n = (cur + dir + images.length) % images.length;
      const it = images[n];
      if (it?.w && it?.h) setRatio(it.w / it.h);
      return n;
    });
  }, []);

  // Swipe (mobile)
  function onPointerDown(e: React.PointerEvent) {
    (e.target as HTMLElement).setPointerCapture?.(e.pointerId);
    down.current = { x: e.clientX, y: e.clientY, t: Date.now() };
  }
  function onPointerUp(e: React.PointerEvent) {
    const start = down.current;
    down.current = null;
    if (!start) return;
    const dx = e.clientX - start.x;
    const dy = e.clientY - start.y;
    const dt = Date.now() - start.t;
    const dist = Math.hypot(dx, dy);
    if (dist < 24) return;
    const horiz = Math.abs(dx) > Math.abs(dy);
    if (horiz && dt < 600) {
      if (dx < 0) go(1);
      else go(-1);
    }
  }

  // Update ratio when the image reveals its natural size
  function onLoad(e: React.SyntheticEvent<HTMLImageElement, Event>) {
    const im = e.currentTarget;
    if (im.naturalWidth && im.naturalHeight) {
      setRatio(im.naturalWidth / im.naturalHeight);
    }
  }

  // Smooth height changes without layout shift using aspect-ratio on container
  const style = useMemo(() => ({ aspectRatio: String(ratio || 1.777) }), [ratio]);

  return (
    <section className="space-y-4">
      <div
        ref={wrapRef}
        className="relative select-none overflow-hidden rounded-lg border border-gray-200 bg-black/5"
        style={style}
        onPointerDown={onPointerDown}
        onPointerUp={onPointerUp}
      >
        {/* Edge fade hints */}
        <div className="pointer-events-none absolute inset-y-0 left-0 w-16 bg-gradient-to-r from-black/20 to-transparent" />
        <div className="pointer-events-none absolute inset-y-0 right-0 w-16 bg-gradient-to-l from-black/20 to-transparent" />

        {/* Image */}
        <img
          ref={imgRef}
          src={img.src}
          alt={img.title || ""}
          className="absolute inset-0 h-full w-full object-contain"
          loading="eager"
          onLoad={onLoad}
        />

        {/* Arrows (desktop) */}
        <button
          aria-label="Previous"
          onClick={() => go(-1)}
          className="absolute left-2 top-1/2 -translate-y-1/2 rounded-full border border-white/30 bg-black/40 px-3 py-1 text-2xl text-white backdrop-blur hover:bg-black/60 hidden sm:inline-flex"
        >
          ‹
        </button>
        <button
          aria-label="Next"
          onClick={() => go(1)}
          className="absolute right-2 top-1/2 -translate-y-1/2 rounded-full border border-white/30 bg-black/40 px-3 py-1 text-2xl text-white backdrop-blur hover:bg-black/60 hidden sm:inline-flex"
        >
          ›
        </button>

        {/* Caption */}
        {(img.title || img.caption) && (
          <div className="absolute bottom-0 left-0 right-0 bg-gradient-to-t from-black/60 to-transparent p-3 text-sm text-white">
            <div className="font-medium">{img.title}</div>
            {img.caption && <div className="text-white/90">{img.caption}</div>}
          </div>
        )}
      </div>

      {/* Thumbnails (no layout shift; fixed size) */}
      <div className="flex items-center gap-2 overflow-x-auto pb-1">
        {images.map((it, idx) => {
          const r = it.w / it.h;
          return (
            <button
              key={it.src + idx}
              onClick={() => setI(idx)}
              className={`relative flex h-16 w-24 shrink-0 items-center justify-center overflow-hidden rounded border transition ${
                i === idx ? "border-gray-900" : "border-gray-200 hover:border-gray-300"
              }`}
              title={it.title || ""}
            >
              <img
                src={it.src}
                alt=""
                className="h-full w-full object-cover"
                style={{ aspectRatio: String(r || 1.5) }}
                loading="lazy"
              />
            </button>
          );
        })}
      </div>

      {/* Help text */}
      <p className="text-xs text-gray-500">
        Tip: swipe on mobile, use ←/→ on desktop. Thumbnails jump without reflow; the main frame keeps a stable aspect.
      </p>
    </section>
  );
}
