import dynamic from "next/dynamic";

const GalleryClient = dynamic(() => import("./components/GalleryClient"), { ssr: false });

export default function GalleryPage() {
  return (
    <main className="mx-auto max-w-5xl px-4 py-8">
      <header className="mb-4">
        <h1 className="text-2xl font-semibold">Gallery</h1>
        <p className="text-sm text-gray-600">Online polish: arrows, swipe, edge fade, and no layout shift.</p>
      </header>
      <GalleryClient />
    </main>
  );
}
